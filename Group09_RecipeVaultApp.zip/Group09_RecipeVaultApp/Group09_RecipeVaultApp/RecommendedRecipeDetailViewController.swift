//
//  RecipeDetailViewController.swift
//  Group09_RecipeVaultApp
//
//  Created by Kuchi,Yudu Eswar Vinay Pratap Kumar on 4/21/23.
//

import UIKit
import youtube_ios_player_helper

class RecommendedRecipeDetailViewController: UIViewController {
    
    
    @IBOutlet var playerView: YTPlayerView!
    
    
    var recipe:[RecipesCategoriesList]!
    var selectedIndex:Int = 0
    var categoryName:String = ""
    var recipesList:[RecipesCategoriesList] = []
    
    @IBOutlet var ingredientsTableView: UITableView!
    
    @IBOutlet var lblRecipe: UILabel!
    
    @IBOutlet var lblInstructions: UILabel!
    
    @IBOutlet var lblCategoryName: UILabel!
    
    var index:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        setupScreenData()
    }
    func setupScreenData(){
        self.title = self.recipe[selectedIndex].recipeName
        playerView.delegate = self
        playerView.load(withVideoId: self.recipe[selectedIndex].videoLink.youtubeID ?? "", playerVars: ["playsinline": "1"])
    
        
        playerView.webView?.backgroundColor = .black
        playerView.webView?.isOpaque = false
        
        self.lblCategoryName.text = self.categoryName
        self.lblRecipe.text  = self.recipe[selectedIndex].recipeName
        self.lblInstructions.text = self.recipe[selectedIndex].instructions
        self.ingredientsTableView.reloadData()
    }
    @IBAction func btnNextRecipeAction(_ sender:UIButton){
        
        selectedIndex += 1
        if self.selectedIndex >= self.recipe.count{
            selectedIndex = 0
        }
        setupScreenData()
        
        
    }
}
extension RecommendedRecipeDetailViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.recipe[selectedIndex].ingredients.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Ingredients", for: indexPath) as! IngredientsTableViewCell
        cell.titleOutlet.text = self.recipe[selectedIndex].ingredients[indexPath.row]
        return cell
    }
}
extension RecommendedRecipeDetailViewController: YTPlayerViewDelegate {
    func playerViewPreferredWebViewBackgroundColor(_ playerView: YTPlayerView) -> UIColor {
        return UIColor.black
    }
    
}
