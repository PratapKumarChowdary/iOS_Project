//
//  ViewController.swift
//  Group09_RecipeVaultApp
//
//  Created by Kuchi,Yudu Eswar Vinay Pratap Kumar on 4/18/23.
//

import UIKit

class HomeViewController: UIViewController {

    var recipesCategories = [RecipesCategoriesData]()
 
    @IBOutlet weak var recipeCollectionViewOL: UICollectionView!
    @IBOutlet weak var lblName: UILabel!
    var  userName = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        self.lblName.text = "Hello! 👋 "+userName
        self.recipesCategories.append(RecipesCategoriesData(recipeCategory: "Vegetarian", recipeImage: "indian", recipesList: [
            RecipesCategoriesList(recipeName: "Tomato Dal", recipeListImage: "dal",videoLink:"https://youtu.be/-rPNmeRkNSE",instructions:"Pick and rinse arhar dal a couple of times in fresh water. Then soak the arhar dal (pigeon pea lentils) in fresh water for 15 to 20 minutes.Later drain all the water from the dal and keep the arhar dal aside.Heat oil or ghee in a stovetop pressure cooker.Add the mustard seeds first and let them crackle on low heat.Then add the cumin seeds and let them splutter.Add the onions, curry leaves and green chilies. Sauté the onions stirring often on low to medium-low heat till they turn translucent.Add the ginger-garlic paste and saute for a few seconds on a low to medium-low heat or till their raw aroma goes away.Now add the tomatoes, red chili powder, turmeric powder, asafoetida (hing) and salt as required. Saute for 2 to 3 minutes on a medium-low heat.Add the lentils and water. Stir and mix well.Pressure cook on high heat for 5 to 6 whistles or till the dal is cooked completely. Timing to cook dal will depend upon the quality of dal, size of pressure cooker and intensity of heat.When the pressure settles down, then only remove the lid.Mash the dal lightly. If the consistency is thick then add water as required to get a medium consistency in the dal. Stir and mix well.Simmer the tomato dal for 5 to 6 minutes on a low to medium-low heat till you get a dal which is neither thin nor thick but having a medium consistency.Once you get the right consistency, check the taste and add more salt if required.Garnish with coriander leaves.Serve tomato pappu hot or warm with steamed rice, mango pickle and vegetable salad.While serving you can add a bit of ghee.", ingredients:[
                "¾ cup toor dal (soaked 20 minutes)",
                "2 tomato (chopped)",
                "small piece tamarind (soaked 20 minutes)",
                "¼ onion (chopped)",
                "¼ tsp turmeric",
                "1 tsp kashmiri red chilli powder",
                "1 chilli (slit)",
                "1 tsp oil",
                "3 cup water",
                "2 tbsp oil",
                "4 clove garlic (crushed)",
                "1 tsp mustard",
                "1 tsp urad dal",
                "1 tsp cumin / jeera",
                "pinch hing / asafoetida",
                "2 dried red chilli (broken)",
                "few curry leaves",
                "1 tsp salt",
                "2 tbsp coriander (chopped)"
            ]),
            RecipesCategoriesList(recipeName: "Mushroom Curry", recipeListImage: "mushroom",videoLink:"https://youtu.be/-rPNmeRkNSE",instructions:"", ingredients:[
                "¾ cup toor dal (soaked 20 minutes)",
                "2 tomato (chopped)",
                "small piece tamarind (soaked 20 minutes)",
                "¼ onion (chopped)",
                "¼ tsp turmeric",
                "1 tsp kashmiri red chilli powder",
                "1 chilli (slit)",
                "1 tsp oil",
                "3 cup water",
            ]),
            RecipesCategoriesList(recipeName: "Chilli Panner", recipeListImage: "chillipanner",videoLink:"https://youtu.be/-rPNmeRkNSE",instructions:"", ingredients:[
                "1 tsp mustard",
                "1 tsp urad dal",
                "1 tsp cumin / jeera",
                "pinch hing / asafoetida",
                "2 dried red chilli (broken)",
                "few curry leaves",
                "1 tsp salt",
            ]),
            RecipesCategoriesList(recipeName: "Panner 65", recipeListImage: "panner65",videoLink:"https://youtu.be/-rPNmeRkNSE",instructions:"", ingredients:[
            
            ]),
            RecipesCategoriesList(recipeName: "Sambar Rice", recipeListImage: "sambarrice",videoLink:"https://youtu.be/-rPNmeRkNSE",instructions:"", ingredients:[
            
            ]),
            RecipesCategoriesList(recipeName: "Panner Pulav", recipeListImage: "pannerpulav",videoLink:"https://youtu.be/-rPNmeRkNSE",instructions:"", ingredients:[
            
            ]),
            RecipesCategoriesList(recipeName: "Veg Biryani", recipeListImage: "vegbiryani",videoLink:"https://youtu.be/-rPNmeRkNSE",instructions:"", ingredients:[
            
            ]),
            RecipesCategoriesList(recipeName: "Veg Fried Rice", recipeListImage: "vegfriedrice",videoLink:"https://youtu.be/-rPNmeRkNSE",instructions:"", ingredients:[
            
            ]),
            RecipesCategoriesList(recipeName: "Veg Noodles", recipeListImage: "vegnoodles",videoLink:"https://youtu.be/-rPNmeRkNSE",instructions:"", ingredients:[
            
            ]),
            RecipesCategoriesList(recipeName: "Brinjal Curry", recipeListImage: "brinjal",videoLink:"https://youtu.be/-rPNmeRkNSE",instructions:"", ingredients:[
            
            ])
        ]))
        self.recipesCategories.append(RecipesCategoriesData(recipeCategory: "Non-Veg", recipeImage: "nonveg", recipesList: [
            RecipesCategoriesList(recipeName: "Biryani", recipeListImage: "vegbiryani",videoLink:"",instructions:"", ingredients:[]),
            RecipesCategoriesList(recipeName: "Fried Rice", recipeListImage: "vegfriedrice",videoLink:"",instructions:"", ingredients:[]),
            RecipesCategoriesList(recipeName: "Noodles", recipeListImage: "vegnoodles",videoLink:"",instructions:"", ingredients:[]),
            RecipesCategoriesList(recipeName: "Brinjal Curry", recipeListImage: "brinjal",videoLink:"",instructions:"", ingredients:[]),
        ]))
        self.recipesCategories.append(RecipesCategoriesData(recipeCategory: "Desert", recipeImage: "deserts", recipesList: [
         
        ]))
        self.recipesCategories.append(RecipesCategoriesData(recipeCategory: "Appetizer", recipeImage: "appetizers", recipesList: [
         
        ]))
        self.recipesCategories.append(RecipesCategoriesData(recipeCategory: "BreakFast", recipeImage: "breakfast", recipesList: [
         
        ]))
    }
}

extension HomeViewController:UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return recipesCategories.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let recipeCell = recipeCollectionViewOL.dequeueReusableCell(withReuseIdentifier: "recipeCell", for: indexPath) as! RecipeCollectionViewCell
        
        recipeCell.recipeImageOL.image = UIImage(named: recipesCategories[indexPath.row].recipeImage)
        recipeCell.titleOutlet.text = recipesCategories[indexPath.row].recipeCategory
        
        recipeCell.layer.cornerRadius = 10
        recipeCell.layer.borderWidth = 1
        recipeCell.layer.borderColor = UIColor.white.cgColor
        
        return recipeCell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let selectedItem = indexPath.item
        performSegue(withIdentifier: "recipeListSegue", sender: recipesCategories[selectedItem])
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let size = (collectionView.frame.size.width-10)/2
        
        return CGSize(width: size, height: size)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "recipeListSegue"{
            if let destination = segue.destination as? RecipeListViewController{
                destination.recipeCategory = sender as? RecipesCategoriesData
            }
        }
    }
}
