//
//  Recipes.swift
//  Group09_RecipeVaultApp
//
//  Created by Kuchi,Yudu Eswar Vinay Pratap Kumar on 4/18/23.
//

import Foundation


class RecipesCategoriesData{
    let recipeCategory:String
    let recipeImage:String
    let recipesList:[RecipesCategoriesList]
    
    init(recipeCategory: String, recipeImage: String, recipesList: [RecipesCategoriesList]) {
        self.recipeCategory = recipeCategory
        self.recipeImage = recipeImage
        self.recipesList = recipesList
    }
}


class RecipesCategoriesList{
    let recipeName:String
    let recipeListImage:String
    let videoLink:String
    let ingredients:[String]
    let instructions:String
    init(recipeName: String, recipeListImage: String,videoLink:String,instructions:String,ingredients:[String]) {
        self.recipeName = recipeName
        self.recipeListImage = recipeListImage
        self.videoLink = videoLink
        self.ingredients = ingredients
        self.instructions = instructions
    }
}
class RecipesDetail{
    let recipeName:[String]
    let recipeListImage:[String]
    
    init(recipeName: [String], recipeListImage: [String]) {
        self.recipeName = recipeName
        self.recipeListImage = recipeListImage
    }
}
extension String {
    var youtubeID: String? {
        let pattern = "((?<=(v|V)/)|(?<=be/)|(?<=(\\?|\\&)v=)|(?<=embed/)|(?<=shorts/))([\\w-]++)"
        
        let regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive)
        let range = NSRange(location: 0, length: count)

        guard let result = regex?.firstMatch(in: self, range: range) else {
            return nil
        }
        
        return (self as NSString).substring(with: result.range)
    }
}
