//
//  RecipeDetailViewController.swift
//  Group09_RecipeVaultApp
//
//  Created by Kuchi,Yudu Eswar Vinay Pratap Kumar on 4/18/23.
//

import UIKit
import youtube_ios_player_helper

class RecipeDetailViewController: UIViewController {
    
    
    
    
    @IBOutlet var playerView: YTPlayerView!
    
    var recipe:[RecipesCategoriesList]!
    var selectedIndex:Int = 0
    var categoryName:String = ""
    var recipesList:[RecipesCategoriesList] = []
    
    
    
    @IBOutlet var ingredientsTableView: UITableView!
    
    @IBOutlet var lblRecipe: UILabel!
    
    @IBOutlet var lblInstructions: UILabel!
    
    @IBOutlet var lblCategoryName: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Function for repeated data updation
        setupScreenData()
    }
    func setupScreenData(){
        self.title = self.recipe[selectedIndex].recipeName
        playerView.delegate = self
        playerView.load(withVideoId: self.recipe[selectedIndex].videoLink.youtubeID ?? "", playerVars: ["playsinline": "1"])
        
        
        playerView.webView?.backgroundColor = .black
        playerView.webView?.isOpaque = false
        
        self.lblCategoryName.text = self.categoryName
        self.lblRecipe.text  = self.recipe[selectedIndex].recipeName
        self.lblInstructions.text = self.recipe[selectedIndex].instructions
        self.ingredientsTableView.reloadData()
    }
    @IBAction func btnNextRecipeAction(_ sender:UIButton){
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        
        if(transition == "recomenSegue"){
            var destination = segue.destination as! RecommendedRecipeDetailViewController
            destination.recipe = recipe
            if (selectedIndex+1) == recipe.count{
                destination.selectedIndex = 0
            }else{
                destination.selectedIndex = selectedIndex + 1
        }
            
            
            
        }
    }
}
extension RecipeDetailViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.recipe[selectedIndex].ingredients.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Ingredients", for: indexPath) as! IngredientsTableViewCell
        cell.titleOutlet.text = self.recipe[selectedIndex].ingredients[indexPath.row]
        return cell
    }
}
extension RecipeDetailViewController: YTPlayerViewDelegate {
    func playerViewPreferredWebViewBackgroundColor(_ playerView: YTPlayerView) -> UIColor {
        return UIColor.black
    }
    
}
class IngredientsTableViewCell: UITableViewCell {
    @IBOutlet weak var titleOutlet: UILabel!
    
    
    
}



