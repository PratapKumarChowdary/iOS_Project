//
//  RecipeCollectionViewCell.swift
//  Group09_RecipeVaultApp
//
//  Created by Kuchi,Yudu Eswar Vinay Pratap Kumar on 4/18/23.
//

import UIKit

class RecipeCollectionViewCell: UICollectionViewCell {
    
    
    
    @IBOutlet weak var recipeImageOL: UIImageView!
    
    
    
    @IBOutlet weak var titleOutlet: UILabel!
    
    
}
