//
//  UserNameViewController.swift
//  Group09_RecipeVaultApp
//
//  Created by Kuchi,Yudu Eswar Vinay Pratap Kumar on 4/25/23.
//

import UIKit

class UserNameViewController: UIViewController {

    @IBOutlet weak var txtUserName: UITextField!
    
    
    @IBOutlet weak var continueBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        continueBtn.isEnabled = false
        continueBtn.layer.cornerRadius = 20
        
        continueBtn.contentEdgeInsets = UIEdgeInsets(
            
            top: 10, left: 20, bottom: 10, right: 20
        )
        
    }
    
    @IBAction func txtUserName(_ sender: UITextField) {
        let username = txtUserName.text!
        
        if username.isEmpty{
            continueBtn.isEnabled = false
        }else{
            continueBtn.isEnabled = true
        }
    }
    
    @IBAction func btnContinueAction(_ sender:UIButton){

    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        
        if(transition == "userNameSegue"){
            var destination = segue.destination as! HomeViewController
            
            destination.userName = txtUserName.text!
            txtUserName.text = ""
            
            continueBtn.isEnabled = false
            
            
            
        }
    }

}
