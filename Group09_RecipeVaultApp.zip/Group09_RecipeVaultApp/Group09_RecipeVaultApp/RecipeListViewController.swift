//
//  RecipeListViewController.swift
//  Group09_RecipeVaultApp
//
//  Created by Kuchi,Yudu Eswar Vinay Pratap Kumar on 4/19/23.
//

import UIKit

class RecipeListViewController: UIViewController {
    
    @IBOutlet weak var recipeListOL: UICollectionView!
    
    @IBOutlet weak var searchbar: UISearchBar!
    
    
    var recipeCategory:RecipesCategoriesData!
    var recipesList:[RecipesCategoriesList] = []
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = self.recipeCategory.recipeCategory
        self.recipesList = self.recipeCategory.recipesList
        self.recipeListOL.reloadData()
        // Do any additional setup after loading the view.

    }
}
extension RecipeListViewController:UISearchBarDelegate{
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        self.recipesList = self.recipeCategory.recipesList
        self.recipeListOL.reloadData()
        searchBar.text = ""
        searchBar.showsCancelButton = false
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        self.recipesList = self.recipeCategory.recipesList.filter({ model in
            model.recipeName.contains(searchBar.text!)
        })
        self.recipeListOL.reloadData()
    }
    func searchBar(_ searchBar: UISearchBar, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        let strUpdated = (searchBar.text! as NSString).replacingCharacters(in: range, with: text)
        self.recipesList = self.recipeCategory.recipesList.filter({ model in
            model.recipeName.contains(strUpdated)
        })
        self.recipeListOL.reloadData()
        searchBar.showsCancelButton = strUpdated != ""
        return true
    }
}
extension RecipeListViewController:UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return recipesList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let recipeListCell = recipeListOL.dequeueReusableCell(withReuseIdentifier: "recipeListCell", for: indexPath) as! RecipeListCollectionViewCell
        recipeListCell.recipeListImageOL.image = UIImage(named: recipesList[indexPath.row].recipeListImage)
        recipeListCell.recipeListLabelOL.text = recipesList[indexPath.row].recipeName
        
        recipeListCell.recipeListImageOL.layer.cornerRadius = 10
        recipeListCell.layer.borderWidth = 1
        recipeListCell.layer.borderColor = UIColor.white.cgColor
        return recipeListCell
    }
    

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let size = (collectionView.frame.size.width-10)/2
        
        return CGSize(width: size, height: size)
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        performSegue(withIdentifier: "recipeDetailSegue", sender: indexPath.row)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "recipeDetailSegue"{
            if let destination = segue.destination as? RecipeDetailViewController{
                destination.recipe = self.recipesList
                destination.selectedIndex = sender as? Int ?? 0
                destination.categoryName = self.recipeCategory.recipeCategory
            }
        }
    }
}
