//
//  RecipeListCollectionViewCell.swift
//  Group09_RecipeVaultApp
//
//  Created by Kuchi,Yudu Eswar Vinay Pratap Kumar on 4/19/23.
//

import UIKit

class RecipeListCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var recipeListImageOL: UIImageView!

    @IBOutlet weak var recipeListLabelOL: UILabel!
}
